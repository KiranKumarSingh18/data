package com.kks.spsec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpsecurityDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
