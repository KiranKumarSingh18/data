package com.kks.spsec.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kks.spsec.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer>{

}
