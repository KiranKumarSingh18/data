package com.kks.spsec.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kks.spsec.entity.Users;
import com.kks.spsec.service.UsersService;

@RestController
@RequestMapping("/users")
public class UsersController {

	@Autowired
	UsersService usersService;
	
	@PostMapping(consumes="application/json")
	public HttpStatus addUser(@RequestBody Users user)
	{
		if(usersService.addUsers(user)) return HttpStatus.OK;
		return HttpStatus.NOT_MODIFIED;
	}
}
