package com.kks.bookpro.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class ABCD 
{
	@Id
	private int abcdid;
	private String abcdname;

}
