package com.kks.bookpro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookproApplicationTests {

	@Test
	void contextLoads() {
	}

}
