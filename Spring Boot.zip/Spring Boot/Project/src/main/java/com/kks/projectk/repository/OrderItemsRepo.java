package com.kks.projectk.repository;

// Import statements for required classes and packages
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

import com.kks.projectk.entity.Customer;
import com.kks.projectk.entity.OrderItems;


public interface OrderItemsRepo extends JpaRepository<OrderItems, Integer> {
    
    //  method to find order items by customer ID
    List<OrderItems> findByCustId(Customer custId);
}
