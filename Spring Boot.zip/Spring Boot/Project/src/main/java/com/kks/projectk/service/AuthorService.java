// Import statements for required classes and packages
package com.kks.projectk.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kks.projectk.entity.Author;
import com.kks.projectk.repository.AuthorRepo;

@Service
public class AuthorService {
    // Autowiring the AuthorRepo bean
    @Autowired
    private AuthorRepo authorRepo;

    // Transactional method to retrieve a list of all authors (read-only)
    @Transactional(readOnly = true)
    public List<Author> getAllAuthors() {
        return authorRepo.findAll();
    }
    
    // Transactional method to retrieve an author by authorId (read-only)
    @Transactional(readOnly = true)
    public Author getAuthorByAuthorId(int authorId) {
        Optional<Author> ot = authorRepo.findById(authorId);
        if (ot.isPresent())
            return ot.get();
        return new Author();
    }
    
    // Transactional method to insert or modify an author
    @Transactional
    public boolean insertOrModifyAuthor(Author author) {
        if (authorRepo.save(author) == null)
            return false;
        return true;
    }
    
    // Transactional method to delete an author by authorId
    @Transactional
    public boolean deleteAuthorByAuthorId(int authorId) {
        long count = authorRepo.count();
        authorRepo.deleteById(authorId);
        if (count > authorRepo.count())
            return true;
        return false;
    }
}
