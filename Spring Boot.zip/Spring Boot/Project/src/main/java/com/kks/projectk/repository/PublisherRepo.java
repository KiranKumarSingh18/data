package com.kks.projectk.repository;

// Import statements for required classes and packages
import org.springframework.data.jpa.repository.JpaRepository;

import com.kks.projectk.entity.Publisher;


public interface PublisherRepo extends JpaRepository<Publisher, Integer> {
    // This repository interface extends JpaRepository for the Publisher entity, which provides basic CRUD operations.
}
