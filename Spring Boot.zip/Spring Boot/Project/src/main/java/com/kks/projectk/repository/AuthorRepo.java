package com.kks.projectk.repository;

// Import statements for required classes and packages
import org.springframework.data.jpa.repository.JpaRepository;

import com.kks.projectk.entity.Author;


public interface AuthorRepo extends JpaRepository<Author, Integer> {
    // This interface extends JpaRepository, which provides basic CRUD (Create, Read, Update, Delete) operations
    
}
