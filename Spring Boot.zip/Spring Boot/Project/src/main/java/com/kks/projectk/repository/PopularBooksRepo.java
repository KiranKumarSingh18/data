package com.kks.projectk.repository;

// Import statements for required classes and packages
import org.springframework.data.jpa.repository.JpaRepository;

import com.kks.projectk.entity.PopularBooks;


public interface PopularBooksRepo extends JpaRepository<PopularBooks, Integer> {
    // This repository interface extends JpaRepository for the PopularBooks entity, which provides basic CRUD operations.
}
