// Import statements for required classes and packages
package com.kks.projectk.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kks.projectk.entity.Book;
import com.kks.projectk.entity.Inventory;
import com.kks.projectk.repository.InventoryRepo;

@Service
public class InventoryService {
    // Autowiring the InventoryRepo bean
    @Autowired
    private InventoryRepo inventoryRepo;

    // Transactional method to retrieve a list of all inventory items (read-only)
    @Transactional(readOnly = true)
    public List<Inventory> getAllInventorys() {
        return inventoryRepo.findAll();
    }

    // Transactional method to retrieve an inventory item by inventoryId (read-only)
    @Transactional(readOnly = true)
    public Inventory getInventoryByInventoryId(int inventoryId) {
        Optional<Inventory> ot = inventoryRepo.findById(inventoryId);
        if (ot.isPresent())
            return ot.get();
        return new Inventory();
    }

    // Transactional method to insert or modify an inventory item
    @Transactional
    public boolean insertOrModifyInventory(Inventory inventory) {
        if (inventoryRepo.save(inventory) == null)
            return false;
        return true;
    }

    // Transactional method to delete an inventory item by inventoryId
    @Transactional
    public boolean deleteInventoryByInventoryId(int inventoryId) {
        long count = inventoryRepo.count();
        inventoryRepo.deleteById(inventoryId);
        if (count > inventoryRepo.count())
            return true;
        return false;
    }

    // Transactional method to retrieve an inventory item by bookId
    @Transactional
    public Inventory getByBookId(Book bookId) {
        return inventoryRepo.findByBookId(bookId);
    }

    // Transactional method to update the quantity of an inventory item
    @Transactional
    public void updateInventory(int bookId, int quantity) {
        inventoryRepo.updateInventory(bookId, quantity);
    }

    // Transactional method to retrieve an inventory item by bookId (using Optional)
    @Transactional
    public Optional<Inventory> getBookByBookId(int bookId) {
        Optional<Inventory> optionalInventory = inventoryRepo.getInventoryByBookId(bookId);
        return optionalInventory;
    }
}
