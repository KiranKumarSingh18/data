package com.kks.projectk.repository;

// Import statements for required classes and packages
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.kks.projectk.entity.Cart;
import com.kks.projectk.entity.Customer;


public interface CartRepo extends JpaRepository<Cart, Integer> {
    // method to find carts by customer
    List<Cart> findByCustomerId(Customer customerId);

    // method to call a stored procedure named "increaseCartQuantity"
    @Procedure("increaseCartQuantity")
    void increaseQuantity(
            @Param("cartId") int cartId,
            @Param("bookId") int bookId);

    //  method to call a stored procedure named "decreaseCartQuantity"
    @Procedure("decreaseCartQuantity")
    void decreaseQuantity(
            @Param("cartId") int cartId,
            @Param("bookId") int bookId);
}
