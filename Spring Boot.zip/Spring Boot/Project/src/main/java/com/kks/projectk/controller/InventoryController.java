package com.kks.projectk.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kks.projectk.entity.Book;
import com.kks.projectk.entity.Inventory;
import com.kks.projectk.service.InventoryService;

@CrossOrigin(origins = {"http://localhost:4200"},allowCredentials = "true")
@RestController
@RequestMapping("/inventory")
public class InventoryController {
    
    // Inject the InventoryService using Spring's autowiring
    @Autowired
    private InventoryService inventoryService;
    
    // Handle GET request to retrieve all inventories
    @GetMapping
    public ResponseEntity<List<Inventory>> getAllInventorys() {
        List<Inventory> inventoryList = inventoryService.getAllInventorys();
        if (inventoryList.size() != 0)
            return new ResponseEntity<List<Inventory>>(inventoryList, HttpStatus.OK);
        return new ResponseEntity<List<Inventory>>(inventoryList, HttpStatus.NOT_FOUND);
    }
    
    // Handle GET request to retrieve an inventory by inventoryId
    @GetMapping(value="/{inventoryId}", produces="application/json")
    public ResponseEntity<Inventory> getInventoryByInventoryId(@PathVariable int inventoryId) {
        Inventory inventory = inventoryService.getInventoryByInventoryId(inventoryId);
        if (inventory != null)
            return new ResponseEntity<Inventory>(inventory, HttpStatus.OK);
        return new ResponseEntity<Inventory>(inventory, HttpStatus.NOT_FOUND);
    }
    
    // Handle POST request to insert an inventory
    @PostMapping(value="/", consumes="application/json")
    public HttpStatus insertInventory(@RequestBody Inventory inventory) {
        inventoryService.insertOrModifyInventory(inventory);
        return HttpStatus.OK;
    }
    
    // Handle PUT request to modify an inventory
    @PutMapping(value="/", consumes="application/json")
    public HttpStatus modifyInventory(@RequestBody Inventory inventory) {
        inventoryService.insertOrModifyInventory(inventory);
        return HttpStatus.OK;
    }
    
    // Handle DELETE request to delete an inventory by inventoryId
    @DeleteMapping("/{inventoryId}")
    public HttpStatus deleteInventory(@PathVariable int inventoryId) {
        if (inventoryService.deleteInventoryByInventoryId(inventoryId))
            return HttpStatus.OK;
        return HttpStatus.NOT_FOUND;
    }
    
    // Handle GET request to update inventory for a book by bookId and quantity
    @GetMapping("/updateinventory/{bookId}/{quantity}")
    public HttpStatus updateInventory(@PathVariable int bookId, @PathVariable int quantity) {
        Book book = new Book();
        book.setBookID(bookId);
        Optional<Inventory> inventory = inventoryService.getBookByBookId(bookId);
        if (inventory.isPresent()) {
            inventoryService.updateInventory(bookId, quantity);
            return HttpStatus.OK;
        } else {
            return HttpStatus.NOT_MODIFIED; // Inventory not found for the specified book
        }
    }
}
