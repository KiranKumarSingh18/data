package com.kks.projectk.repository;

// Import statements for required classes and packages
import org.springframework.data.jpa.repository.JpaRepository;

import com.kks.projectk.entity.Customer;


public interface CustomerRepo extends JpaRepository<Customer, Integer> {
    
    //  method to find a customer by email and password
    Customer findCustomerIdByEmailAndPassword(String email, String password);
    
}
