// Import statements for required classes and packages
package com.kks.projectk.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kks.projectk.entity.Customer;
import com.kks.projectk.entity.OrderItems;
import com.kks.projectk.repository.OrderItemsRepo;

@Service
public class OrderItemsService {
    // Autowiring the OrderItemsRepo bean
    @Autowired
    private OrderItemsRepo orderItemsRepo;

    // Transactional method to retrieve a list of all order items (read-only)
    @Transactional(readOnly = true)
    public List<OrderItems> getAllOrderItemss() {
        return orderItemsRepo.findAll();
    }

    // Transactional method to retrieve a list of order items for a specific customer
    @Transactional(readOnly = true)
    public List<OrderItems> getBooksByCustomrId(Customer customer) {
        // Using the findByCustId method of the OrderItemsRepo to retrieve order items for the customer
        return orderItemsRepo.findByCustId(customer);
    }

    // Transactional method to retrieve an order item by orderItemsId (read-only)
    @Transactional(readOnly = true)
    public OrderItems getOrderItemsByOrderItemsId(int orderItemsId) {
        Optional<OrderItems> ot = orderItemsRepo.findById(orderItemsId);
        if (ot.isPresent())
            return ot.get();
        return new OrderItems();
    }

    // Transactional method to insert or modify an order item
    @Transactional
    public boolean insertOrModifyOrderItems(OrderItems orderItems) {
        if (orderItemsRepo.save(orderItems) == null)
            return false;
        return true;
    }

    // Transactional method to delete an order item by orderItemsId
    @Transactional
    public boolean deleteOrderItemsByOrderItemsId(int orderItemsId) {
        long count = orderItemsRepo.count();
        orderItemsRepo.deleteById(orderItemsId);
        if (count > orderItemsRepo.count())
            return true;
        return false;
    }
}
