// Import statements for required classes and packages
package com.kks.projectk.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kks.projectk.entity.Admin;
import com.kks.projectk.entity.PopularBooks;
import com.kks.projectk.repository.AdminRepo;
import com.kks.projectk.repository.PopularBooksRepo;

@Service
public class AdminService {
    // Autowiring the AdminRepo and PopularBooksRepo beans
    @Autowired
    private AdminRepo adminRepo;
    
    @Autowired
    PopularBooksRepo popularBooksRepo;

    // Transactional method to retrieve a list of all admins (read-only)
    @Transactional(readOnly = true)
    public List<Admin> getAllAdmins() {
        return adminRepo.findAll();
    }
    
    // Transactional method to retrieve an admin by adminId (read-only)
    @Transactional(readOnly = true)
    public Admin getAdminByAdminId(int adminId) {
        Optional<Admin> ot = adminRepo.findById(adminId);
        if (ot.isPresent())
            return ot.get();
        return new Admin();
    }
    
    // Transactional method to insert or modify an admin
    @Transactional
    public boolean insertOrModifyAdmin(Admin admin) {
        if (adminRepo.save(admin) == null)
            return false;
        return true;
    }
    
    // Transactional method to delete an admin by adminId
    @Transactional
    public boolean deleteAdminByAdminId(int adminId) {
        long count = adminRepo.count();
        adminRepo.deleteById(adminId);
        if (count > adminRepo.count())
            return true;
        return false;
    }
    
    // Transactional method to count the number of admins with a specific email and password
    @Transactional
    public Integer countOfAdmin(String email, String password) {
        Admin a = adminRepo.findAdminIdByEmailAndPassword(email, password);
        if (a != null) {
            return a.getAdminId();
        } else {
            return null;
        }
    }
    
    // Transactional method to get a list of popular books
    @Transactional(readOnly = true)
    public List<PopularBooks> getPopularBooks() {
        // Calling a method 'popularBook' (which seems to be missing) from 'adminRepo'
        // and returning a list of popular books from 'popularBooksRepo'
        adminRepo.popularBook();
        return popularBooksRepo.findAll();
    }
}
