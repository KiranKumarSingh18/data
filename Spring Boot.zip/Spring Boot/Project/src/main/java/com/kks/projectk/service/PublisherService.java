// Import statements for required classes and packages
package com.kks.projectk.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kks.projectk.entity.Publisher;
import com.kks.projectk.repository.PublisherRepo;

@Service
public class PublisherService {
    // Autowiring the PublisherRepo bean
    @Autowired
    private PublisherRepo publisherRepo;

    // Transactional method to retrieve a list of all publishers (read-only)
    @Transactional(readOnly = true)
    public List<Publisher> getAllPublishers() {
        return publisherRepo.findAll();
    }

    // Transactional method to retrieve a publisher by publisherId (read-only)
    @Transactional(readOnly = true)
    public Publisher getPublisherByPublisherId(int publisherId) {
        Optional<Publisher> ot = publisherRepo.findById(publisherId);
        if (ot.isPresent())
            return ot.get();
        return new Publisher();
    }

    // Transactional method to insert or modify a publisher
    @Transactional
    public boolean insertOrModifyPublisher(Publisher publisher) {
        if (publisherRepo.save(publisher) == null)
            return false;
        return true;
    }

    // Transactional method to delete a publisher by publisherId
    @Transactional
    public boolean deletePublisherByPublisherId(int publisherId) {
        long count = publisherRepo.count();
        publisherRepo.deleteById(publisherId);
        if (count > publisherRepo.count())
            return true;
        return false;
    }
}
