package com.kks.rest.exception;

public class ResourceNotModifiedException extends RuntimeException{

}
