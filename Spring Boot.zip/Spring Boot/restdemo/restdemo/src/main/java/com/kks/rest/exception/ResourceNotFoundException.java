package com.kks.rest.exception;

public class ResourceNotFoundException extends RuntimeException
{
	
}
