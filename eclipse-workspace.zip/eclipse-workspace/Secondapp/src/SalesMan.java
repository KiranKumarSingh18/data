
public class SalesMan extends Employee{
	
	private int points;
	public SalesMan() {
		
	}
	public SalesMan(int sum, String name, int age, int empid, double salary, String orgName, int points) {
		super(sum, name, age, empid, salary, orgName);
		this.points = points;
	}
	public int getPoints() {
		return points;
	}
	public void setPoints(int points) {
		this.points = points;
	}
	
}
