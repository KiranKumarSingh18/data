class A{
	 int x =10;

//	public int getX() {
//		return x;
//	}
//
//	public void setX(int x) {
//		this.x = x;
//	}
	
	
	
}

class B extends A{
	int x =20 ;

//	public void getB() {
//		System.out.println("x = "+getX());
//		System.out.println("y = "+y);
//	}

	public void setB() {
		System.out.println(super.x);
		System.out.println(x);
	}

	
	
}
public class Main {
	public static void main(String[] args) {
		B b1 = new B();
		b1.setB();
//		b1.getB();
//		System.out.println(b1.x);
//		System.out.println(b1.y);
		
	}
}
