
public class HomeLoan extends Loan {
	 int houseid;
	    int areaid;
	   
	    public HomeLoan() {}
	   
	    public HomeLoan(int interestrate, int loanid, int tenure, int houseid, int areaid) {
	        super(interestrate, loanid, tenure);
	        this.houseid = houseid;
	        this.areaid = areaid;
	    }
	   
	    public int getHouseid() {
	        return houseid;
	    }
	   
	    public void setHouseid(int houseid) {
	        this.houseid = houseid;
	    }
	   
	    public int getAreaid() {
	        return areaid;
	    }
	   
	    public void setAreaid(int areaid) {
	        this.areaid = areaid;
	    }
}
