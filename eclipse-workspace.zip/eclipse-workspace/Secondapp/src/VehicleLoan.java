
public class VehicleLoan extends Loan{
	  int typeofvehicle;
	    int price;
	   
	    public VehicleLoan() {}
	   
	    public VehicleLoan(int interestrate, int loanid, int tenure, int typeofvehicle, int price) {
	        super(interestrate, loanid, tenure);
	        this.typeofvehicle = typeofvehicle;
	        this.price = price;
	    }
	   
	    public int getTypeofvehicle() {
	        return typeofvehicle;
	    }
	   
	    public void setTypeofvehicle(int typeofvehicle) {
	        this.typeofvehicle = typeofvehicle;
	    }
	   
	    public int getPrice() {
	        return price;
	    }
	   
	    public void setPrice(int price) {
	        this.price = price;
	    }
}
