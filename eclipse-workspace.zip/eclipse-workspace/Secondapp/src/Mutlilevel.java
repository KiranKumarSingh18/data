
class Apple {
	int x = 10;
	
	public Apple() {
		System.out.println("a created");
	}
	public void msg() {
		System.out.println("frpm a");
	}
}

class Ball extends Apple{
	int b = 20;
	public Ball() {
		System.out.println("B creazted");
	}
	public void msg() {
		System.out.println("frpm b");
	}
}

class C extends Ball{
	int c = 30;
	public C() {
		System.out.println("C created");
	}
	public void msg() {
		System.out.println("frpm c");
	}
}

public class Mutlilevel{
	public static void main(String[] args) {
	C c1 = new C();
	System.out.println(c1.x +" "+c1.b+" "+c1.c);
	c1.msg();
	}
}

