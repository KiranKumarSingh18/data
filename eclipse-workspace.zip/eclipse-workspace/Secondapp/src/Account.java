import java.time.LocalDate;
import java.util.Objects;

public class Account {
	private int accountNumber;
	private double balance;
	private String accountHolderName;
	private LocalDate openedDate;
	
	
	public Account() {
		
	}


	public Account(int accountNumber, double balance, String accountHolderName, LocalDate openedDate) {
		
		this.accountNumber = accountNumber;
		this.balance = balance;
		this.accountHolderName = accountHolderName;
		this.openedDate = openedDate;
	}


	@Override
	public String toString() {
		return "Account\naccountNumber=" + accountNumber + "\nbalance=" + balance + "\naccountHolderName="
				+ accountHolderName + "\nopenedDate=" + openedDate;
	}


	@Override
	public int hashCode() {
		return Objects.hash(accountHolderName, accountNumber, balance, openedDate);
	}


//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		Account other = (Account) obj;
//		return Objects.equals(accountHolderName, other.accountHolderName) && accountNumber == other.accountNumber
//				&& Double.doubleToLongBits(balance) == Double.doubleToLongBits(other.balance)
//				&& Objects.equals(openedDate, other.openedDate);
//	}	
//	
	
	public boolean equals(Object obj) {
		if(obj instanceof Account) {
			Account a = (Account)obj;
			return (accountNumber == a.accountNumber && balance == a.balance && accountHolderName.equals(a.accountHolderName) && openedDate.equals(a.openedDate));
		}
		return false;
	}
	
}
