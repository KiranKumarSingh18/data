
public class Loan {
	 int interestrate;
	    int loanid;
	    int tenure;
	   
	    public Loan() {}
	   
	    public Loan(int interestrate, int loanid, int tenure) {
	        this.interestrate = interestrate;
	        this.loanid = loanid;
	        this.tenure = tenure;
	    }
	   
	    public int getInterestrate() {
	        return interestrate;
	    }
	   
	    public void setInterestrate(int interestrate) {
	        this.interestrate = interestrate;
	    }
	   
	    public int getLoanid() {
	        return loanid;
	    }
	   
	    public void setLoanid(int loanid) {
	        this.loanid = loanid;
	    }
	   
	    public int getTenure() {
	        return tenure;
	    }
	   
	    public void setTenure(int tenure) {
	        this.tenure = tenure;
	    }
}
