package com.generic;

public class List<T> {
	private T[] list; 
	
	private int back=-1;
	
	
	public List(T[] list) {
		this.list = list;
	}
	
	public boolean isFull() {
		if(back==list.length-1)
			return true;
		return false;
	}
	
	public boolean isEmpty() {
		if(back ==-1)
			return true;
		else
			return false;
	}
	
	public void addAtBegining(T element) {
		if(back==-1) {
			append(element);
		}
		else {
			if(!(isFull())) {
				int tempInd = back;
				T temp = list[back];
				list[++back] = temp;
				for(int i = tempInd;i>0;i--) {
					list[i]=list[i-1];
				}
				list[0] = element;
			}
			else
				System.out.println("List is full.. add at begin is not possible");
		}
	}
	
	public void append(T element) {
		if(!(isFull())) 
			list[++back] = element;
		else
			System.out.println("List is full");
	}
	
	public void insertAtPosition(int position, T element)
	{
		if(!(isFull())){
			int tempInd = back;
			T temp = list[back];
			list[++back] = temp;
			for(int i = tempInd;i>position;i--) {
				list[i]=list[i-1];
			}
			list[position] = element;
		}
		else
			System.out.println("List is full... add at position is not posible");
	}
	
	public void deleteFromEnd() {
		if(!isEmpty()) {
			System.out.println( list[back--]);
		}
		else
			System.out.println("List is Empty....");
	}
	
	public void deleteFirst() {
		if(!isEmpty()) {
			System.out.println(list[0]);
			for(int i =0;i<back;i++) {
				list[i] = list[i+1];
			}
			back--;
			
		}
		else
			System.out.println("no elements to delete in begining");
	}
	
	public void deleteElement(T element) {
		if(!isEmpty()) {
			for(int i =0;i<= back;i++) {
				if(list[i]== element) {
					System.out.println(list[i]+ " at index "+i+" is deleted");
					for(int j =i;j<back;j++) {
						list[j] = list[j+1];
					}
					back--;
				}
			}
		}
		
	}
	
	public void printList() {
		for(int i =0;i<=back;i++) {
			System.out.print(list[i]+" ");
		}
		System.out.println();
	}
}
