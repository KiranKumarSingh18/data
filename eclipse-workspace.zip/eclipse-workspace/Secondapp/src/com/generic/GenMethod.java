package com.generic;

public class GenMethod<T extends Number> {
	
	T[] a;
	public GenMethod(T[] a) {
		this.a = a;
	}
	
	
	public double getAverage(){
		double sum =0.0;
		for(int i =0;i<a.length;i++)
			sum = sum + a[i].doubleValue();
		return sum/a.length;
	}
	// Wild card
	public boolean areAveragesSame(GenMethod<?> gm) {
		return getAverage() == gm.getAverage();
	}
	
//	public static <T> void printArray(T[] a) {
//		for(int i =0;i<a.length;i++) {
//			System.out.println(a[i]);
//		}
//	}
//	public static <T extends Number>double getAverage(T[] a){
//		double sum =0.0;
//		for(int i =0;i<a.length;i++)
//			sum = sum + a[i].doubleValue();
//		return sum/a.length;
//	}
	
}
