package com.generic.assignment;
class  GenDemo{
	
}

public class Test {

}
