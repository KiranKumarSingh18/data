//package com.generic.assignment;
//
//interface GenDemo<T>{
//	void addFirst(T element);
//	void append(T element);
//	boolean searchElement(T element);
//}
//
//class Stack<T> implements GenDemo<T>{
//	T[] a;
//	public int index = -1;
//	public Stack(T[] a) { this.a= a;}
//	public boolean isFull() {
//		return index ==9;
//	}
//	public boolean isEmpty() {
//		return index == -1;
//	}
//	
//
////	public void MyStack(T[] a) {
//////	public MyStack(Double[] a) {
////		super(a);
////	}
//
//	public void push(T element) {
////	public void push(Double element) {
//		if(!isFull()) {
//			a[++index] = element;
//		}
//		else
//			throw new RuntimeException("Stack Overflow");
//		
//	}
//	
//	public T pop() {
////	public Double pop() {
//		if(!isEmpty())
//			return a[index--];
//		throw new RuntimeException("Stack Underflow");
//	}
//}
//
//
//
//
//public class GenInterfaceAss {
//
//}
