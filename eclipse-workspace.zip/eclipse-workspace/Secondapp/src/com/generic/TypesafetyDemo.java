package com.generic;

public class TypesafetyDemo <T,U>{
	T obj1;
	U obj2;
	/*
	static T obj;// not Allowed
	T ob = new T(); // not allowed
	T[] ob1 = new T[3]; //not allowed
	*/
	public TypesafetyDemo(T obj1, U obj2) {
		this.obj1 = obj1;
		this.obj2= obj2;
	}
	
	/* Not allowed
	public static T getObj1() {
		return obj1;
	}
	*/
	public T getObj1() {
		return obj1;
	}
	public U getObj2() {
		return obj2;
	}
}

