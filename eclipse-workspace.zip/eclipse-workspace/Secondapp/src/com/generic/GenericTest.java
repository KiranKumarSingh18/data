package com.generic;


interface GenDemo<T>{
	void printArray(T[] a);
}

/*
class GenDemoImpl <T> implements GenDemo<T>{
	public void printArray(T[] a) {
		for(int i =0;i<a.length;i++)
			System.out.println(a[i]);
	}
}
*/

class GenDemoImplStr implements GenDemo<String>{
	public void printArray(String[] a) {
		for(int i =0;i<a.length;i++)
			System.out.println(a[i]);
	}
}

class GenDemoImplEmp implements GenDemo<Employee>{
	public void printArray(Employee[] a) {
		for(int i =0;i<a.length;i++)
			System.out.println(a[i]);
	}
}





















class StackA<T> {
	T[] a;
	public int index = -1;
	public StackA(T[] a) { this.a= a;}
	public boolean isFull() {
		return index ==9;
	}
	public boolean isEmpty() {
		return index == -1;
	}
}

//class MyStack<T> extends StackA<T>{
class MyStack extends StackA<Double>{

//	public MyStack(T[] a) {
	public MyStack(Double[] a) {
		super(a);
	}

//	public void push(T element) {
	public void push(Double element) {
		if(!isFull()) {
			a[++index] = element;
		}
		else
			throw new RuntimeException("Stack Overflow");
		
	}
	
//	public T pop() {
	public Double pop() {
		if(!isEmpty())
			return a[index--];
		throw new RuntimeException("Stack Underflow");
	}
}






public class GenericTest {
	public static void main(String[] args) {
//		GenDemoImpl<String> gd1 = new GenDemoImpl<String>();
//		gd1.printArray(new String[] {"Welcome","Hello","Bye Bye"});
		
		GenDemoImplStr gd1 = new GenDemoImplStr();
		gd1.printArray(new String[] {"Welcome","Hello","Bye Bye"});
		
		Employee[] eArr = {new Employee(102,"Babu",2000),new Employee(103,"Charan",3000),new Employee(101,"Ajay",1000)};
		
//		GenDemoImpl<Employee> gd2 = new GenDemoImpl<Employee>();
		GenDemoImplEmp gd2 = new GenDemoImplEmp();
		
		gd2.printArray(eArr);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	/*	
//		MyStack<Integer> ms1 = new MyStack<Integer>(new Integer[10]);
		MyStack ms1 = new MyStack(new Double[10]);
		for(int i =1;i<=10;i++)
			ms1.push(i*2.5);
		for(int i =1;i<=10;i++)
			System.out.println(ms1.pop());
	*/
	}
}
