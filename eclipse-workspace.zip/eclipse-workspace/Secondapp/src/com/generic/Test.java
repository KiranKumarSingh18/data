package com.generic;

public class Test {

	public static void main(String[] args) {
		
		GenMethod<Integer> gm1=new  GenMethod<Integer>(new Integer[] {10,20,30,40,50});
		System.out.println(gm1.getAverage());
		
		GenMethod<Double> gm2=new  GenMethod<Double>(new Double[] {10.0,20.0,30.0,40.0,50.0});
		System.out.println(gm2.getAverage());
		
		System.out.println(gm1.areAveragesSame(gm2));
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		GenMethod gm = new GenMethod();
//		System.out.println(gm.getAverage(new Integer[] {10,20,30,40,50}));
//		System.out.println(gm.getAverage(new Double[] {10.45,20.32,30.67,40.56,50.32}));
//		System.out.println(gm.getAverage(new String[] {"hai","hello"}));
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/* Generic mathods
		Integer[] i = {10,20,30,40,50};
		String[] s = {"Welcome","Hello","Farewel"};
		
		GenMethod.printArray(i);
		GenMethod.printArray(s);
		GenMethod.printArray(new Employee[] {new Employee(101,"babu",2000),new Employee(102,"Ajay",1000)});
		*/
		
/* Genereic class with multiple parameter		
		TypesafetyDemo<String,Employee> ts = new TypesafetyDemo<String,Employee>("Marketing",new Employee(104,"kiran",40000));
		System.out.println(ts.getObj1()+ "  " +ts.getObj2());	
*/

		/*Stack<Employee> es = new Stack<Employee>(new Employee[10]);
		es.push(new Employee(102,"kiran",4000));
		es.push(new Employee(103,"kin",7000));
		es.push(new Employee(104,"kn",460));
		es.push(new Employee(105,"kumar",4560));
		es.push(new Employee(106,"kum",034300));
		
		for(int i =1;i<=10;i++) {
			System.out.println(es.pop());
		}*/		
		
//		Stack<String> s1 = new Stack<String>(new String[10]);
//		for(int i=1 ;i<=10;i++) {
//			s1.push(i +" welcome");
//		}
//		for(int i =1;i<=10;i++) {
//			System.out.println(s1.pop());
//		}
//		
//		Stack<Double> s3 = new Stack<Double>(new Double[10]);
//		for(int i=1 ;i<=10;i++) {
//			s3.push(i* 2.5);
//		}
//		for(int i =1;i<=10;i++) {
//			System.out.println(s3.pop());
//		}
		
//		TypesafetyDemo<Integer> ts1 = new TypesafetyDemo<Integer>(new Integer(786));
//		System.out.println(ts1.getObj());
//		
//		TypesafetyDemo<String> ts2 = new TypesafetyDemo<String>(new String("Welcome"));
//		System.out.println(ts2.getObj());
//		Integer i = ts2.getObj();
//		System.out.println(i);
		/*Stack s =new Stack(new Integer[10]);
		for(int i=1 ;i<=10;i++) {
			s.push(i * 10);
		}
		for(int i =1;i<=10;i++) {
			System.out.println(s.pop());
		}
		
		Stack s2 =new Stack(new String[10]);
		for(int i=1 ;i<=10;i++) {
			s2.push(i +" welcome");
		}
		for(int i =1;i<=10;i++) {
			System.out.println(s2.pop());
		}
		*/
//		String s = "100a";
//		
//		int x = Integer.parseInt(s);
//		System.out.println(x+100);
//		
//		s = new String("786.45");
//		double d = Double.parseDouble(s);
//		System.out.println(d);
//		
		
		//		Integer iobj1 = new Integer(10);
//		int x = 20;
//		Integer iobj2 = new Integer(x);
//		Integer iobj3 = Integer.valueOf(30);
//		
//		int a = iobj1.intValue();
//		int b = iobj2.intValue();
//		int c = iobj3.intValue();
//		System.out.println(a+" "+ b+ " "+c);
		
//		int x = iobj1.intValue();
//		float y = iobj1.floatValue();
//		double z = iobj1.doubleValue();
//		System.out.println(a +" " +y+ " "+z);
		
//		Double dobj = new Double(999999.9);
//		int xx = dobj.intValue();
//		System.out.println(xx);
		
//		Integer iobj = 10;  //autboxing
//		System.out.println(iobj);  //autounboxing
	}

}
