package com.generic;

public class TestList {

	public static void main(String[] args) {
		List<Integer> l1 = new List<Integer>(new Integer[10]);
//		System.out.println(l1.isEmpty());
		for(int i =1;i<=10;i++)
			l1.addAtBegining(i * 10);
		l1.printList();
//		l1.printList();
////		l1.addAtBegining(1000);
//		l1.deleteFromEnd();
//		l1.deleteFromEnd();
//		l1.deleteFromEnd();
//		System.out.println();
//		l1.deleteFirst();
//		System.out.println();
//		l1.deleteElement(30);
//		l1.printList();
//		
////		l1.addAtBegining(1000);
////		l1.printList();
//		l1.insertAtPosition(2, 500);
//		l1.printList();	
		
		List<String> ls = new List<String>(new String[10]);
		}

}
