package com.loanmela;

public class VehicleLoan extends Loan{
	private static double vechicleValue;
	private double vehicleValue;

	public VehicleLoan() {
		super();
		// TODO Auto-generated constructor stub
	}

	public VehicleLoan(int tenure, double roi, double vehicleValue) {
		super(vehicleValue * 0.8, tenure, roi);
		this.vehicleValue = vehicleValue;
	}

	
	public double calculateEmi() {
		return ((this.getLoanAmount()) + (this.getLoanAmount() * (this.getRoi() /100)*this.getTenure()))/(this.getTenure() * 12);  
	}
	
	
}
