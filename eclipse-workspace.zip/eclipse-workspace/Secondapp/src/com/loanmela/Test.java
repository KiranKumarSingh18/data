package com.loanmela;

public class Test {
	public static void main(String[] args) {
		Loan l = LoanMela.approveLoan();
		System.out.println(l.calculateEmi());
	}
}
