package com.loanmela;

public class PersonalLoan extends Loan{
	private double income;

	public PersonalLoan() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PersonalLoan( int tenure, double roi, double income) {
		super(income * 0.7, tenure, roi);
		this.income = income;
	}
	public double calculateEmi() {
		return ((this.getLoanAmount()) + (this.getLoanAmount() * (this.getRoi() /100)*this.getTenure()))/(this.getTenure() * 12);
		
	}
	
	
}
