package com.loanmela;

public class HomeLoan extends Loan{
	
	private double propertyValue;

	
	public HomeLoan(int tenure, double roi,double propertyValue) {
		super(propertyValue * 0.9 , tenure, roi);
		this.propertyValue = propertyValue;
		
	}
	
	public double calculateEmi() {
		return ((this.getLoanAmount()) + (this.getLoanAmount() * (this.getRoi() /100)*this.getTenure()))/(this.getTenure() * 12);  
	}
	
	

}
