package com.loanmela;

import java.util.Scanner;

public class LoanMela {
	public static Loan approveLoan() {
		switch(new java.util.Random().nextInt() % 3) {
		case 0: 
			System.out.println("Home Loan");
			return new HomeLoan(3,5,100000);
		case 1:
			System.out.println("Vehicle Lona");
			return new VehicleLoan(3,5,100000);
		default:
			System.out.println("Personal Loan");
			return new PersonalLoan(3,5,100000);
		}
	}
}
