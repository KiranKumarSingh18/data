package com.interfacedemo;


interface Sim{
	void call();
}

class KeypadPhone{
	String brand;
	double price;
	String network;
	public KeypadPhone(String brand, double price, String network) {
		super();
		this.brand = brand;
		this.price = price;
		this.network = network;
	}
	
	
	
}

class TouchPhone extends KeypadPhone implements Sim{

	int storage;
	
	public TouchPhone(String brand, double price,String network, int storage) {
		super(brand,price,network);
		this.storage = storage;
	}
	public void call() {
		
		System.out.println("Calling with " + network);
	}
	
	
}

public class Test {
	public static void main(String[] args) {
		TouchPhone p = new TouchPhone("OnePlus", 27000, "Jio", 16);
		p.call();
	}
}
