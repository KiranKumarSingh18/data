
//import static com.abc.utility.Calculator.*;

import java.time.LocalDate;

public class Test {

	public static void main(String[] args) {
//		System.out.println(PI);
//		System.out.println(sum(789,999));
//		System.out.println(power(4, 5));
//		
//		SalesMan sm = new SalesMan(7001,"Ajay Saxena",34,5678,67000,"Prolifics Corp",9);
//		System.out.println("Ssn          "+ sm.getSsn());
//		System.out.println("Name         "+ sm.getName());
//		System.out.println("Age          "+ sm.getAge());
//		System.out.println("Empid        "+ sm.getEmpid());
//		System.out.println("Salary       "+ sm.getSalary());
//		System.out.println("Orgname      "+ sm.getOrgName());
//		System.out.println("Incentives   "+ sm.getPoints() *75);
//		System.out.println("total salary "+ (sm.getSalary()+sm.getPoints() * 75));
//		
//		
//		VehicleLoan v = new VehicleLoan(12, 1234, 5, 4, 700000);
//        HomeLoan h = new HomeLoan(12, 1234, 5, 5544, 531163);
//       
//        // Account properties
//        System.out.println("Rate of intereat:     " + v.getInterestrate());
//        System.out.println("Loanid:               " + v.getLoanid());
//        System.out.println("Tenure:               " + v.getTenure());
//       
//        // VehicleLoan properties
//        System.out.println("Type of Vehicle:      " + v.getTypeofvehicle());
//        System.out.println("Price of the Vehicle: " + v.getPrice());
//       
//        // HomeLoan properties
//        System.out.println("Houae ID:             " + h.getHouseid());
//        System.out.println("Area ID:              " + h.getAreaid());
		
		Account a= new Account(7001,15000.00,"Ajay Saxena", LocalDate.now());
		Account a1= new Account(7001,15000.00,"Ajay Saxena", LocalDate.now());
		
		System.out.println(a.equals(a1));
	}

}
