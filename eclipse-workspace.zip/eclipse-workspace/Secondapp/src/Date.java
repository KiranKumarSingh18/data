import java.time.LocalDateTime;



public class Date {
	public static void main(String[] args) {
		LocalDateTime ld = LocalDateTime.now();
		System.out.println(ld.getDayOfMonth()+"/"+ld.getMonthValue()+"/"+ld.getYear());
		
		LocalDateTime dob = LocalDateTime.of(2000, 10, 2,18, 30, 45);
		System.out.println(dob.getDayOfMonth()+"/"+dob.getMonthValue()+"/"+dob.getYear());
		
		LocalDateTime lt = LocalDateTime.now();
		System.out.println(lt.getHour() + ":" + lt.getMinute() + ":" + lt.getSecond());
		
//		LocalDateTime tob = LocalDateTime.of(18, 30, 45);
//		System.out.println(tob.getHour() + ":" + tob.getMinute() +":" +tob.getSecond());
	}

}
