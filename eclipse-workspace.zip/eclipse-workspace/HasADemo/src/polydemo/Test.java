package polydemo;

//final class Parent{
//	final public int sum(int x,int y) { return x+y;}
//}
//
//class Child extends Parent{
//	public int sum(int x, int y) {return x-(-y);}
//}
public class Test {

	public static void main(String[] args) {
//		A a1 = new B();
//		a1.methodA();
////		a1.methodB();   Error
//		System.out.println(a1.x);
////		System.out.println(a1.y);
//		
//		a1 = new C();
//		a1.methodA();
////		a1.methodC();   Error
//		System.out.println(a1.x);
////		System.out.println(a1.z);
		
//		A a1 = new B();
//		a1.show();
//		
//		a1 = new C();
//		a1.show();
	int noC=0,noR =0,noT=0;
		for(int i =0; i<10; i++) {
			Shape s = ShapesFactory.produceShape();
			System.out.println(s.area());
			if(s instanceof Cirlce) noC++;
			else if(s instanceof Rectangle) noR++;
			else noT++;
		}
		
		System.out.println("Circle      :" +noC);
		System.out.println("Rectangel   :" + noR);
		System.out.println("Triangle    :" + noT);
	}
}
