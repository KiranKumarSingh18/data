package polydemo;

public class Cirlce extends Shape {
	private double radius;

	public Cirlce(double radius) {
		this.radius = radius;
	}
	
	public double area() {
		return 3.14 * radius * radius;
	}
}
