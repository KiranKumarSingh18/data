package polydemo;

abstract public class Shape {
	abstract public double area(); //do nothing method, the slo purpose is for overriding
}

