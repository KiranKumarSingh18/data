package collections;

import java.util.LinkedList;
import java.util.ListIterator;

public class ArrayL {
	public static void main(String[] args) {

		LinkedList<Employee> elist = new LinkedList<Employee>();
		
		elist.add(new Employee(102,"Babu",2000));
		elist.add(new Employee(103,"Ajay",9000));
		elist.add(new Employee(101,"Charan",6000));
		
		System.out.println(elist.remove(new Employee(102,"Babu",2000)));
		for(Employee e : elist)
			System.out.println(e);
		
		
		
		
		
//		LinkedList<String> slist = new LinkedList<>();
//		slist.add("Welcome");
//		slist.add("Hello");
//		slist.add("Apple");
//		slist.add("kiran");
//		
//		LinkedList<String> slist2 = new LinkedList<>();
//		slist2.add("Welcome");
//		slist2.add("Hello");
//		slist2.add("Apple");
////		slist2.add("Banana");
//		
//		
//		System.out.println(slist.containsAll(slist2));
		
//		slist.retainAll(slist2);
		
//		for(String s : slist)
//			System.out.println(s);

		
//		slist.addAll(slist2);
		
//		System.out.println("Empty :"+ slist.isEmpty());
//		System.out.println(slist.size());
//		slistst.clear();
		
//		System.out.println(slist.remove(2) + " is deleted");
//		System.out.println(slist.remove("Apple"));
		
//		for(int i =0;i<slist.size();i++) {
//			System.out.println(slist.get(i));
//		}
//		System.out.println();
//		ListIterator itr = slist.listIterator();
//		while(itr.hasNext())
//			System.out.println(itr.next());
//		System.out.println();
//		while(itr.hasPrevious())
//			System.out.println(itr.previous());
//		
//		System.out.println(slist.size());
//		System.out.println("Empty :"+ slist.isEmpty());
//		System.out.println(slist.contains("Apple"));
	}
}
