package collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;


public class SetS {
	public static void main(String[] args) {
		

		
//		TreeSet<Employee> set = new TreeSet<>(new EmployeeEmpidComparator());
//		set.add(new Employee(102, "Babu", 2000));
//		set.add(new Employee(104, "Dinesh", 4000));
//		set.add(new Employee(101, "Ajay", 1000));
//		set.add(new Employee(103, "Charan", 3000));
////		System.out.println(set.add(new Employee(103, "Charan", 3000)));
//		for(Employee i : set)
//			System.out.println(i);
		
		
//		TreeSet<Employee> set = new TreeSet<>(new EmployeeEnameComparator());
//		set.add(new Employee(102, "Ajay", 2000));
//		set.add(new Employee(104, "Charan", 4000));
//		set.add(new Employee(101, "Babu", 1000));
//		set.add(new Employee(103, "Dinesh", 3000));
////		System.out.println(set.add(new Employee(103, "Charan", 3000)));
//		for(Employee i : set)
//			System.out.println(i);
		

		TreeSet<Employee> set = new TreeSet<>(new EmployeeSalaryComparator());
		set.add(new Employee(102, "Ajay", 2000.10));
		set.add(new Employee(104, "Charan", 4000));
		set.add(new Employee(101, "Babu", 2000.20));
		set.add(new Employee(103, "Dinesh", 3000));
//		System.out.println(set.add(new Employee(103, "Charan", 3000)));
		for(Employee i : set)
			System.out.println(i);
		
		
		
		
//		Employee e1 = new Employee(102,"Babu", 2000);
//		Employee e2 = new Employee(102,"Babu", 2000);
//		System.out.println(e1.compareTo(e2));
//		set.add(new Employee(102,"Babu", 2000));
//		set.add(30);
//		set.add(15);
//		set.add(25);
//		set.add(35);
//		set.add(12);
//		set.add(17);
//		set.add(null);   --> throws NullPointerException
//		set.add(10);
		
//		
//		Iterator<Integer> itr = set.iterator();
//		
//		while(itr.hasNext())
//			System.out.println(itr.next());
//		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		Employee e1 = new Employee(103,"Charan",3000);
//		Employee e2 = new Employee(103,"Charan",3000);
//		
//		System.out.println(e1.hashCode()+"    "+e2.hashCode());
//		HashSet<Employee> eset= new HashSet<>();
//		eset.add(new Employee(102, "Babu", 2000));
//		eset.add(new Employee(104, "Dinesh", 4000));
//		eset.add(new Employee(101, "Ajay", 1000));
//		eset.add(new Employee(103, "Charan", 3000));
////		eset.add(new Employee());
//		
//		System.out.println(eset.add(new Employee(103, "Charan", 3000)));
//		for(Employee s:eset)
//			System.out.println(s);
//		System.out.println();
//		Iterator itr = eset.iterator();
//		
//		while(itr.hasNext())
//			System.out.println(itr.next());
		
		
		
		
		
		
//		HashSet<String> hs = new HashSet<>();
//		hs.add("Hello");
//		hs.add("Welcome");
//		hs.add("Apple");
//		hs.add("Zebra");
//		hs.add("Banana");
//		System.out.println(hs.isEmpty());
//		System.out.println(hs.size());
//		System.out.println(hs.contains("Hello"));
//		
//		for(String s:hs)
//			System.out.println(s);
//		
//		Iterator itr = hs.iterator();
//		
//		while(itr.hasNext())
//			System.out.println(itr.next());
	}
}
