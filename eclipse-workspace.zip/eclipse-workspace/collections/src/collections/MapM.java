package collections;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;

public class MapM {

	public static void main(String[] args) {

		TreeMap<Employee,String> hmap = new TreeMap<>(new EmployeeEnameComparator());
		hmap.put(new Employee(102, "Ajay", 2000),"Sales");
		hmap.put(new Employee(104, "Dinesh", 4000),"Marketing");
		hmap.put(new Employee(103, "Charan", 3000),"Finance");
		hmap.put(new Employee(101, "Babu", 1000),"IT");

		
		Set<Entry<Employee,String>> entries = hmap.entrySet();
		for(Entry<Employee,String> k: entries)
			System.out.println(k.getKey()+"      "+k.getValue());
		
		
		
		
		
		
		
		
//		TreeMap<String,String> hmap = new TreeMap<>();
//		hmap.put("Abc@gmail.com", "abc@123");
//		hmap.put("Bbc@yahoo.com", "bbc@321");
//		hmap.put("Xyz@rediff.com", "Xyz@123");
//		hmap.put("Something@cool.com", "CoolSome");
//		
//		
//		Set<Entry<String,String>> entries = hmap.entrySet();
//		for(Entry<String,String> e: entries)
//			System.out.println(e.getKey()+"      "+e.getValue());
//		

		
		
		
		
		
		
		
		
		
		
		
		
		
//		
//		LinkedHashMap<Employee,String> hmap = new LinkedHashMap<>();
//		hmap.put(new Employee(102, "Ajay", 2000),"Sales");
//		hmap.put(new Employee(104, "Dinesh", 4000),"Marketing");
//		hmap.put(new Employee(103, "Charan", 3000),"Finance");
//		hmap.put(new Employee(101, "Babu", 1000),"IT");
//
//		
//		Set<Entry<Employee,String>> entries = hmap.entrySet();
//		for(Entry<Employee,String> k: entries)
//			System.out.println(k.getKey()+"      "+k.getValue());
//		
//		
		
		
		
		
		
		
		
//		HashMap<String,String> hmap = new HashMap<>();
//		hmap.put("Abc@gmail.com", "abc@123");
//		hmap.put("bbc@yahoo.com", "bbc@321");
//		hmap.put("Xyz@rediff.com", "Xyz@123");
//		hmap.put("Something@cool.com", "CoolSome");
//		
//		Set<Entry<String,String>> entries = hmap.entrySet();
//		
//		for(Entry<String,String> e : entries)
//			System.out.println(e.getKey()+  "      "  + e.getValue());
		
		
		
//		LinkedHashMap<Employee,String> hmap = new LinkedHashMap<>();
//		hmap.put(new Employee(102, "Ajay", 2000),"Sales");
//		hmap.put(new Employee(104, "Dinesh", 4000),"Marketing");
//		hmap.put(new Employee(103, "Charan", 3000),"Finance");
//		hmap.put(new Employee(101, "Babu", 1000),"IT");
////		hmap.put("Something@cool.com", "Some");
//		
//		Set<Employee> keys = hmap.keySet();
//		for(Employee k: keys)
//			System.out.println(k+"      "+hmap.get(k));
//		
//		Collection<String> values = hmap.values();
//		for(String v: values)
//			System.out.println(v);
		
		
		
		
		
//		HashMap<String,String> hmap = new HashMap<>();
//		hmap.put("Abc@gmail.com", "abc@123");
//		hmap.put("bbc@yahoo.com", "bbc@321");
//		hmap.put("Xyz@rediff.com", "Xyz@123");
//		hmap.put("Something@cool.com", "CoolSome");
//		hmap.put("Something@cool.com", "Some");
//		
//		Set<String> keys = hmap.keySet();
//		for(String k: keys)
//			System.out.println(k+"      "+hmap.get(k));
//		
//		Collection<String> values = hmap.values();
//		for(String v: values)
//			System.out.println(v);
		
//		System.out.println(hmap.replace("Xyz@rediff.com", "zzz@123"));
//		System.out.println(hmap.replace("Xyz@rediff.com", "Xyz@123", "zzz@123"));
//		System.out.println(hmap.remove("bbc@yahoo.com", "bbc@321"));
		
		
//		System.out.println(hmap.size());
//		System.out.println(hmap.containsKey("bbc@yahoo.com"));
//		System.out.println(hmap.containsValue("abc@123"));
//		System.out.println(hmap.get("Xyz@rediff.com"));
//		System.out.println(hmap.get("Something@cool.com"));
//		hmap.clear();
//		System.out.println(hmap.size());
	}

}
