package threads;

//class SecondThread extends Thread{
// 
//	public SecondThread() {
//		start();
//	}
//public void run() {
//	for(int i = 1; i <= 1000; i++) {
//		System.out.println("Second Loop: " +  i);
//	}
//}
//}


class ChildTread implements Runnable{
	Thread t;
	int priority;
	boolean flag = true;
	 long x = 0L;
	public ChildTread(String name,int priority) {
		t = new Thread(this,name);
		this.t.setPriority(priority);
		t.start();
	}

	public void run() 
	{
		while(flag)
			x++;
		System.out.println(t.getName()+" is terminated");
	}
	public void stop() {
		flag = false;
		
	}
}


public class Test {
	public static void main(String[] args) throws Exception{
		ChildTread hpt = new ChildTread("HP Child",8);
		ChildTread lpt = new ChildTread("LP Child",3);
		try {
			Thread.sleep(3000);
		}catch(InterruptedException ex) {
			System.out.println(ex);
		}
		hpt.stop();
		lpt.stop();
		
		try {
			hpt.t.join();
			lpt.t.join();
		}
		catch(InterruptedException ex) {
			System.out.println(ex);
		}
		System.out.println("HPT executed for "+ hpt.x);
		System.out.println("LPT executed for " + lpt.x);
		System.out.println("Main is terminated");
	
		
		
		
		
		
		
//		Thread ct1 = new Thread(new SecondThread());
//		ct1.start();
		
//		for(int i = 1; i <= 1000; i++) {
//			System.out.println("First Loop: " +  i);
//		}
		
//		Thread t = Thread.currentThread();
//		t.setPriority(8);
		
		//returns the reference of current(main thread in this case) thread
//		System.out.println("Thread Name: " +t.getName());
//		System.out.println("Thread Priority: " + t.getPriority());
//		System.out.println("Thread Group: " + t.getThreadGroup());
//		
//		t.setName("FirstThread");
		
//		
//		System.out.println();
//		System.out.println("Thread Name: " +t.getName());
//		System.out.println("Thread Priority: " + t.getPriority());
//		System.out.println("Thread Group: " + t.getThreadGroup());
		
	}
}

//		try 
//		{
//			for(int i = 1; i <= 10; i++) {
//				System.out.println(t.getName() +"  "+  i);
//				t.sleep(1000);
//			} 			
//		}catch (InterruptedException e) {
//			
//			e.printStackTrace();
//		}