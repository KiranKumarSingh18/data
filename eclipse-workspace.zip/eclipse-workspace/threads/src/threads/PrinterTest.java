package threads;

class Printer{
	synchronized public void print(String[] messages) {
		for(String m : messages) {
			System.out.print(m + " ");
		}
		System.out.println();
	}
	
}

class ChildTread1 implements Runnable{
	Thread t;
	Printer p;
	String[] messages;
	public ChildTread1(Printer p,String[] messages) {
		t = new Thread(this);
		this.p = p;
		this.messages = messages;
		t.start();
	}
	
	public void run() {
		p.print(messages);
	}
}

public class PrinterTest {
	public static void main(String[] args) {
		Printer printer = new Printer();
		ChildTread1 ct1 = new ChildTread1(printer, new String[] {"Hello", "Welcome", "Bye Bye"});
		ChildTread1 ct2 = new ChildTread1(printer, new String[] {"Apple", "Banana", "CustardApple"});
		ChildTread1 ct3 = new ChildTread1(printer, new String[] {"Java", "Dotnet", "Python"});
		
		try {
			ct1.t.join();
			ct2.t.join();
			ct3.t.join();
		}
		catch(InterruptedException ex) {
			System.out.println(ex);
		}
		System.out.println("Main is terminated");
	
	}
}
