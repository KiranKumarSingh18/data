package com.kks.hibernate.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.CascadeType;


@Entity
public class Department {
	@Id
	@Column(name="deptno")
	private int departmentNo;
	
	@Column(name="deptname")
	private String departmentname;
	
	private String location;
	
	// for eager fetching
//	@OneToMany(fetch = FetchType.EAGER,cascade = CascadeType.ALL)
//	@JoinColumn(name="deptno")
	@OneToMany(mappedBy="department")
	List<Employee> employees;
	
	public Department() {}

	public Department(int departmentNo, String departmentname, String location) {
		this.departmentNo = departmentNo;
		this.departmentname = departmentname;
		this.location = location;
	}

	public int departmentNo() {
		return departmentNo;
	}

	public void setAddressid(int departmentNo) {
		this.departmentNo = departmentNo;
	}

	public String getDepartmentname() {
		return departmentname;
	}

	public void setDepartmentname(String departmentname) {
		this.departmentname = departmentname;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	
	
}
