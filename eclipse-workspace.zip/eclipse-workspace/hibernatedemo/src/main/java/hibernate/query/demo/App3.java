package hibernate.query.demo;


import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.query.Query;

import com.kks.hibernate.entity.Address2;
import com.kks.hibernate.util.HibernateUtli;

public class App3
{
	public static void main(String[] args)
	{
		SessionFactory factory = HibernateUtli.buildSessionFactory();
		Session session = factory.openSession();
		
		Criteria crt = session.createCriteria(Address2.class);
		crt.addOrder(Order.desc("streetname"));
		List<Address2> list = crt.list();
		for(Address2 a : list)
		{
			System.out.println(a.getAddressId()+"    "+a.getHouseNo()+"   "+a.getStreetname()+"    "+a.getCityName()+"    "+a.getStreetname()+"   "+a.getStateName());
		}
		
//		Query<Address2> qry = session.createNamedQuery("getAllAddress",Address2.class);
		
		
//		Query<Address2> qry = session.createQuery("select a from Address2 a where a.addressId > ?1",Address2.class);
//		qry.setInteger(1, 7002);
		
//		Query<Address2> qry = session.createQuery("from Address2",Address2.class);
//		Query<Address2> qry = session.createQuery("select a from Address2 a",Address2.class);
//		List<Address2> alist = qry.getResultList();
//		for(Address2 a : alist)
//		{
//			System.out.print(a.getAddressId()+"    "+a.getHouseNo()+"    "+a.getStreetname());
//			System.out.println(a.getCityName()+"    "+a.getStateName());
//			System.out.println();
//		}
		
		
		/*Query qry = session.createSQLQuery("select * from address");
		List<Object[]> list = qry.list();
		for(Object[] obj : list)
		{
			for(Object o: obj)
				System.out.print(o+"    ");
			System.out.println();
		ko}*/

		session.close();
		HibernateUtli.shutdown();
	}
}





/*Query<Address2> qry = session.createNativeQuery("select * from address", Address2.class);
		List<Address2> alist = qry.getResultList();
		for(Address2 a : alist)
		{
			System.out.println(a.getAddressId()+"    "+a.getHouseNo()+"    "+a.getStreetname());
			System.out.println(a.getCityName()+"    "+a.getStateName());
			System.out.println();
		}*/