package inheritance.strategy.demo.entity;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
			//Single table
//@DiscriminatorColumn(name="emp_type")
//@Inheritance(strategy=InheritanceType.SINGLE_TABLE)


			// Three Tables
//@Inheritance(strategy = InheritanceType.JOINED)
			// tow tables
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
abstract public class Employee {
	
	@Id
	@Column(name="empid")
	private int emloyeeId;
	
	@Column(name="emp_name")
	private String employeeName;
	
	public Employee() {}

	public Employee(int emloyeeId, String employeeName) {
		super();
		this.emloyeeId = emloyeeId;
		this.employeeName = employeeName;
	}

	public int getEmloyeeId() {
		return emloyeeId;
	}

	public void setEmloyeeId(int emloyeeId) {
		this.emloyeeId = emloyeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	
}
