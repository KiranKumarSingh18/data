package com.kks.spmvc.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.kks.spmvc.beans.User;
import com.kks.spmvc.dao.UserDAO;

@Controller      
public class LoginController 
{
	@Autowired
	UserDAO udao;
	
	//@RequestMapping(value="/loginPage",method=RequestMethod.GET)
	@GetMapping("/loginPage")
	public String getLoginPage()
	{
		return "Login";
	}

	@PostMapping("/validateUser")
	public String authenticateUser(@RequestParam("uname")String username,@RequestParam("pwd")String password, Model model,HttpServletResponse response) 
	{
		
		User user = new User(username,password);
		if(udao.searchUser(user))
		{
			response.addCookie(new Cookie("username",username));
			return "Services";
		}
		String message = "Invalid Username / Password... Sorry";
		model.addAttribute("userMessage", message);
		return "Display";
	}
	

}


//@PostMapping("/validateUser")
//public String authenticateUser(@RequestParam("uname")String username,@RequestParam("pwd")String password, ModelMap model) 
//{
//	String message = "Invalid Username / Password... Sorry";
//	if(username.equals("Ajay") && password.equals("Ajay@123"))
//		message = "Hello " + username + ", Welcome to Spring MVC World";
//	model.addAttribute("userMessage", message);
//	return "Display";
//}





/* Not Recomended
@PostMapping("/validateUser")
public ModelAndView authenticateUser(@RequestParam("uname")String username,@RequestParam("pwd")String password) 
{
	String message = "Invalid Username / Password... Sorry";
	if(username.equals("Ajay") && password.equals("Ajay@123"))
		message = "Hello " + username + ", Welcome to Spring MVC World";
	return new ModelAndView("Display","userMessage",message);
}
*/













//	@PostMapping("/validateUser")
//	public String authenticateUser(@RequestParam("uname")String username,@RequestParam("pwd")String password, Model model) 
//	{
//		String message = "Invalid Username / Password... Sorry";
//		User user = new User(username,password);
//		//UserDAO udao = new UserDAO();
//		if(udao.searchUser(user))
//			message = "Hello " + username + ", Welcome to Spring MVC World";
//		model.addAttribute("userMessage", message);
//		return "Display";
//	}