package com.bookstore;

public class NoMoreBooksCanBeAdded extends Exception {
	String message;

	

	public NoMoreBooksCanBeAdded(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "NoMoreBooksCanBeAdded [message=" + message + "]";
	}
	
}
