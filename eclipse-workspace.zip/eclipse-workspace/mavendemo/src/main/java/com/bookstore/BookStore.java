package com.bookstore;

import java.util.Objects;

public class BookStore {
	private Book[] books;
	private String storeName;
	private String location;
	public BookStore() {
		super();
	}
	public BookStore(Book[] books, String storeName, String location) {
		super();
		this.books = books;
		this.storeName = storeName;
		this.location = location;
	}
	public Book[] getBooks() {
		return books;
	}
	public void setBooks(Book[] books) {
		this.books = books;
	}
	public String getStoreName() {
		return storeName;
	}
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	
	
	
	
	public void addBook(Book book) throws NoMoreBooksCanBeAdded {
		int count=0;
		for(int i =0;i<books.length;i++) {
			if(!(Objects.isNull(books[i])))
				count++;
		}
		if(count <5) {
			this.books[count] = book;
		}
		else {
			throw new NoMoreBooksCanBeAdded("No more Books Can be addes");
		}
	}
	
	public boolean searchBooksByTitle(String bookTitle) throws SearchBooksByTitle {
		
		for(int i =0;i<books.length;i++) {
			if(!(Objects.isNull(books[i]))) {
			if(this.books[i].getBookTitle().equals(bookTitle))
				return true;
			
			}
		}
		throw new SearchBooksByTitle("Book not found");
		
	}
	
	public void showBooksByCategory(String category) {
		int count =0;
		for(int i =0;i<books.length;i++) {
			if(!(Objects.isNull(books[i]))) {
			if(this.books[i].getCategory().equals(category))
				System.out.println("Book Title :"+books[i].getBookTitle() + ", Book Author :" +books[i].getAuthor()+", Book price :"+books[i].getPrice()+", Book Category "+books[i].getCategory());
				count++;
				
			}
		}
		if(count==0) {
			System.out.println("Book with "+category+" not found");
		}
	}
	
	public void showAllBooks() {
		System.out.println("All Books---------");
		for(int i =0;i<books.length;i++) {
				if(!(Objects.isNull(books[i])))
				System.out.println("Book Title :"+books[i].getBookTitle() + ", Book Author :" +books[i].getAuthor()+", Book price :"+books[i].getPrice()+", Book Category "+books[i].getCategory());
				
				
			
		}
	}
	
}
