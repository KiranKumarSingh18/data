package com.bookstore;

public class Main {
	public static void main(String[] args)  {

Book[] bList = new Book[5];

bList[0] = new Book(1,"First","Kiran",3000,"tech");
bList[1] = new Book(2,"C","kiran",2000,"tech");
bList[2] = new Book(3,"Java","kiran",2000,"tech");
bList[3] = new Book(4,"last","kiran",2000,"nontech");
BookStore bs = new BookStore(bList,"Kiran Book Store","Madhapur");

//bs.showBooksByCategory("nontech");
bs.showAllBooks();
try {
	bs.addBook(new Book(5,"five","auth",300,"nontech"));
} catch (NoMoreBooksCanBeAdded e) {
	
	System.out.println(e);
}
bs.showAllBooks();
try {
	bs.addBook(new Book(6,"six","auth",300,"nontech"));
} catch (NoMoreBooksCanBeAdded e) {
	
	System.out.println(e);
}

try {
	System.out.println(bs.searchBooksByTitle("C"));
} catch (SearchBooksByTitle e) {
	// TODO Auto-generated catch block
	System.out.println(e);
}
		
	}
}













































