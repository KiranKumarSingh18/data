import java.sql.SQLException;

public class Utility 
{
	
	
	public static void divide(int x, int y) throws SQLException{
		if(y!=0)
			System.out.println(x/y);
		else {
//			try {
				throw  new SQLException();
//			}
//		
		}
		
	}
}
