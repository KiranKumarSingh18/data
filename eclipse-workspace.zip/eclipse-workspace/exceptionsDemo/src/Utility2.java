
public class Utility2 {
	
	public static void a() {
		throw new ArithmeticException();
	}
	public static void b() {
		a();
	}
	public static void c() {
		b();
	}
	public static void d() {
		c();
	}
}
