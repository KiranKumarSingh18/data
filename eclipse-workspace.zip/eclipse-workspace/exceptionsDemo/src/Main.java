public class Main{
	public static void main(String[] args){
		Employee e = new Employee();
		try {
			e.setAge(17);
			e.setName("kiran");
			
			System.out.println("age " +e.getAge());
			System.out.println("name "+e.getName());
		} catch (InvalidAgeException e1) {
			
			System.out.println(e1);
		}
		
		
//		Account a1 = new Account(7001,"John Miller", 7500);
//		try {
//			Transaction.withdraw(a1, 6501);
//		}
//		catch(InsufficientBalanceException ex) {
//			System.out.println(ex);
//		}
//		System.out.println("After the transaction your balance is " + a1.getBalance());
	}
}