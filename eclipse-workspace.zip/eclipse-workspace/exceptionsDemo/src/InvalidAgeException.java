
public class InvalidAgeException extends Exception {
	String message;

	public InvalidAgeException(String message) {
		
		this.message = message;
	}

	public InvalidAgeException() {
		
	}

	@Override
	public String toString() {
		return "InvalidAgeException [message=" + message + "]";
	}
	
}
