
public class Employee {
	int age;
	String name;
	public int getAge() {
		return age;
	}
	public void setAge(int age) throws InvalidAgeException {
		validateAge(age);
		this.age = age;
	}
	private void validateAge(int age) throws InvalidAgeException {
		if(age<18)
			throw new InvalidAgeException("Age should greater than or equal to 18");
			
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
