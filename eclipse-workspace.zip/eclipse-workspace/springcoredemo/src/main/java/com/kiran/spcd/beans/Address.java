package com.kiran.spcd.beans;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

//@Component //indicates that this is a bean class whose xml configuration is not required
//@Service
//@Repository
@Controller
public class Address {
	private String hno="1-2-3";
	private String streeName="MG Street";
	private String city="Ahmadabad";
	private String state="Gujarath";
	
	public Address() {}

	public Address(String hno, String streeName, String city, String state) {
		
		this.hno = hno;
		this.streeName = streeName;
		this.city = city;
		this.state = state;
	}

	public String getHno() {
		return hno;
	}

	public void setHno(String hno) {
		this.hno = hno;
	}

	public String getStreeName() {
		return streeName;
	}

	public void setStreeName(String streeName) {
		this.streeName = streeName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	
	
}
