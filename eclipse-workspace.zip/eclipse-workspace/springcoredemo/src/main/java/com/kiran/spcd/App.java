package com.kiran.spcd;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.kiran.spcd.beans.Country;
import com.kiran.spcd.beans.Person;
import com.kiran.spcd.beans.Wish;
import com.kiran.spcd.config.AppConfig;

import java.util.Map.Entry;

public class App 
{
    public static void main( String[] args )
    {
//        ClassPathXmlApplicationContext container = new ClassPathXmlApplicationContext("beans.xml");
    	
    	AnnotationConfigApplicationContext container = new AnnotationConfigApplicationContext(AppConfig.class);
        
        Person p = container.getBean(Person.class);
        System.out.println(p.getSsn()+"    "+p.getName()+"   "+p.getAge());
      
        System.out.println(p.getAddress().getHno()+"    "+p.getAddress().getStreeName());
        System.out.println(p.getAddress().getCity()+"    "+p.getAddress().getState());
        container.close();
    }
}








//Country c = container.getBean("ctry",Country.class);
//System.out.println("Country Name :- "+ c.getCountryName());
//System.out.println("Currency Name :- "+ c.getCurrencyName());
//System.out.println("States :- ");
//for(Entry<String,String> e: c.getStates().entrySet())
//	System.out.println(e.getKey()+" :- "+e.getValue());


//        FileSystemXmlApplicationContext container = new FileSyatemXmlApplicationContext("c://.....");

/*
        Wish w1 = container.getBean("wish1",Wish.class);
        System.out.println(w1.getMessage());

Wish w2 = container.getBean("wish1",Wish.class);
w2.setMessage("Spring Welcomes You");
System.out.println(w2.getMessage());
System.out.println(w1.getMessage()); */

