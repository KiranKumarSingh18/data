package com.kiran.spcd.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;


import com.kiran.spcd.beans.Address;
import com.kiran.spcd.beans.Person;

@Configuration
@ComponentScan(basePackages="com.kiran.spcd.beans")
public class AppConfig 
{
	/*@Bean
//	@Scope("prototype")
	public Address address() {
		return new Address("1-2-3","MG Street","Bangalore","Karnataka");
	}
	
	@Bean
	public Person person() {
		Person p = new Person();
		p.setSsn(101);
		p.setName("Ajay Saxena");
		p.setAge(23);
		return p;
	}
	*/
}
