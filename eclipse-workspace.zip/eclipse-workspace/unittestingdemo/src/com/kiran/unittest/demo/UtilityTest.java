package com.kiran.unittest.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import com.kiran.testdemo.Utility;

class UtilityTest {
	
	Utility u = null;

	@BeforeEach
	void setUp() throws Exception {
		u = new Utility();
	}

	@AfterEach
	void tearDown() throws Exception {
		u = null;
	}

	@Test
	void isElementExistTest() {
		int[] arr = {1,2,3,4,5};
		assertEquals(true,u.isElementExist(arr,3));
	}
	
	@ParameterizedTest
	@CsvSource(value= {"true,12","false,11","true,20"})
	void isEvenTest(boolean expVal, int actVal) {
		assertEquals(expVal, u.isEven(actVal));
	}

	
}
