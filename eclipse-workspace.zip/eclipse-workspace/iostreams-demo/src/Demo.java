import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
public class Demo {
	public static void main(String[] args)  {
		
		FileInputStream fis = null;
		ObjectInputStream ois = null;
		try {
			fis= new FileInputStream("c:\\Users\\KKshatri\\Desktop\\emp.dat");
			ois = new ObjectInputStream(fis);
			Employee e = (Employee)ois.readObject();
			System.out.println(e.getEmpid()+"      "+e.getEname());
			System.out.println(e.getSalary()+"      "+e.getDob());
			ois.close();
			fis.close();
		}
		catch(IOException ex) {
			System.out.println(ex);
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		
		
//		Employee e1 = new Employee(101,"Ajay Saxena",25000,LocalDate.of(2000, 10,30));
//		
//		FileOutputStream fos = null;
//		ObjectOutputStream oos = null;
//		try
//		{
//			fos = new FileOutputStream("c:\\Users\\KKshatri\\Desktop\\emp.dat");
//			oos = new ObjectOutputStream(fos);
//			oos.writeObject(e1);
//			oos.close();
//			fos.close();
//		}
		
		
		
		
				
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		File file = new File("c:\\Users\\KKshatri\\Desktop\\Dummy.java");
//		System.out.println(file.getName());
//		System.out.println(file.getParent());
//		System.out.println(file.length());
//		System.out.println("File   " + file.isFile());
//		System.out.println("Directory   " + file.isDirectory());
//		System.out.println("executable " + file.canExecute());
//		System.out.println(file.delete());
	
	
	
	
	
	
	
	
	
	
	
	
// Serialization	
	
	
	
	
	



	}
}
