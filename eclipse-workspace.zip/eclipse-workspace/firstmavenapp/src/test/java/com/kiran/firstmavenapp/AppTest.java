package com.kiran.firstmavenapp;


public class AppTest 
{

}
