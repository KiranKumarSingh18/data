package com.kiran.firstmavenapp;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.kiran.model.Calculator;

public class TestCalculator {
	
	Calculator c = null;
	@BeforeEach
	public void setUp() throws Exception{
		c = new Calculator();
	}
	
	@AfterEach
	public void tearDown() throws Exception{
		c = null;
	}
	
	@Test
	public void testSquare() {
		assertEquals(225,c.square(15));
	}
	
	@Test
	public void testSume() {
		assertEquals(150,c.sum(10,20,30,40,50));
	}
	
	@Test
	public void testPower() {
		assertEquals(125,c.power(5,3));
	}

}
