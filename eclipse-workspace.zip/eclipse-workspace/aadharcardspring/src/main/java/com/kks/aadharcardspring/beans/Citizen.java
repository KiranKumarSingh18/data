package com.kks.aadharcardspring.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Citizen {
	@Autowired
	private AadharCard aadhar;
	private long mobile=8328319281L;
	
	public Citizen() {}

	public Citizen(AadharCard aadhar, long mobile) {
		super();
		this.aadhar = aadhar;
		this.mobile = mobile;
	}

	public AadharCard getAadhar() {
		return aadhar;
	}

	public void setAadhar(AadharCard aadhar) {
		this.aadhar = aadhar;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	
	
}
