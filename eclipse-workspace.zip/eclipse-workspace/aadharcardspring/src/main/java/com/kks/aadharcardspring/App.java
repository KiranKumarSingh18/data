package com.kks.aadharcardspring;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.kks.aadharcardspring.beans.Citizen;
import com.kks.aadharcardspring.config.AppConfig;

public class App 
{
    public static void main( String[] args )
    {
//    	ClassPathXmlApplicationContext container = new ClassPathXmlApplicationContext("beans.xml");
    	AnnotationConfigApplicationContext container = new AnnotationConfigApplicationContext(AppConfig.class);
    	Citizen c = container.getBean("citizen",Citizen.class);
    	System.out.println("Name :- " + c.getAadhar().getName());
    	System.out.println("Date of Birth :- " + c.getAadhar().getDob());
    	System.out.println("Gender :- " + c.getAadhar().getGender());
    	System.out.println("Aadhar No :- " + c.getAadhar().getAadharNo());
    	System.out.println("Mobile No :- " + c.getMobile());
    	
    }
}
