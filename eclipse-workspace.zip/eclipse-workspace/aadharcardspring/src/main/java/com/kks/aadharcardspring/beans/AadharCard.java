package com.kks.aadharcardspring.beans;

import org.springframework.stereotype.Component;

@Component
public class AadharCard {
	private long aadharNo=123456789L;
	private String name="Kiran Kumar Singh";
	private String dob="18-04-2002";
	private String gender="Male";
	
	public AadharCard() {
		
	}

	public AadharCard(long aadharNo, String name, String dob, String gender) {
		super();
		this.aadharNo = aadharNo;
		this.name = name;
		this.dob = dob;
		this.gender = gender;
	}

	public long getAadharNo() {
		return aadharNo;
	}

	public void setAadharNo(long aadharNo) {
		this.aadharNo = aadharNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
	
	
}
