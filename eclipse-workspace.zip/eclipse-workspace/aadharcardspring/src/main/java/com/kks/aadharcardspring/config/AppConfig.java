package com.kks.aadharcardspring.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.kks.aadharcardspring.beans.AadharCard;
import com.kks.aadharcardspring.beans.Citizen;

@Configuration
public class AppConfig {
	
	@Bean
	public AadharCard aadharcard() {
		return new AadharCard(123456789,"Kiran Kumar Singh", "18-04-2002","Male");
	}
	@Bean
	public Citizen citizen() {
		return new Citizen(aadharcard(),8328319281L);
	}
}
